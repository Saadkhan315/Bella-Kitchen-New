/* Bella Kitchen website interactions
   Add only a real, authorised business WhatsApp number below.
   Use international digits only, with country code and no +, spaces, or dashes. */
(() => {
  'use strict';

  const menuToggle = document.getElementById('menuToggle');
  const navigation = document.getElementById('navigation');
  const year = document.getElementById('year');
  const whatsappOrder = document.getElementById('whatsappOrder');
  const whatsappNote = document.getElementById('whatsappNote');
  const floatingTop = document.querySelector('.back-to-top-floating');
  const navLinks = navigation ? navigation.querySelectorAll('a[href^="#"]') : [];

  // Keep the footer year current.
  if (year) year.textContent = String(new Date().getFullYear());

  // Mobile navigation: accessible toggle, close on selection or Escape.
  const closeMenu = () => {
    if (!menuToggle || !navigation) return;
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open navigation');
    navigation.classList.remove('is-open');
    document.body.classList.remove('menu-open');
  };

  if (menuToggle && navigation) {
    menuToggle.addEventListener('click', () => {
      const isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
      menuToggle.setAttribute('aria-expanded', String(!isOpen));
      menuToggle.setAttribute('aria-label', isOpen ? 'Open navigation' : 'Close navigation');
      navigation.classList.toggle('is-open', !isOpen);
      document.body.classList.toggle('menu-open', !isOpen);
    });

    navLinks.forEach((link) => link.addEventListener('click', closeMenu));
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closeMenu();
    });
    window.addEventListener('resize', () => {
      if (window.innerWidth > 760) closeMenu();
    }, { passive: true });
  }

  // WhatsApp stays safely disabled until the owner configures a real number.
  const restaurantWhatsAppNumber = ''; // Example format: 923001234567 (replace with your authorised number)
  if (whatsappOrder && whatsappNote) {
    const cleanNumber = restaurantWhatsAppNumber.replace(/\D/g, '');
    const validNumber = /^\d{10,15}$/.test(cleanNumber);

    if (validNumber) {
      const message = 'Hello Bella Kitchen! I would like to ask about your menu.';
      whatsappOrder.href = `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
      whatsappOrder.target = '_blank';
      whatsappOrder.rel = 'noopener noreferrer';
      whatsappNote.textContent = 'WhatsApp opens in a new tab. Please confirm your contact details before publishing.';
      whatsappOrder.removeAttribute('aria-describedby');
    } else {
      whatsappOrder.href = '#contact';
      whatsappOrder.setAttribute('aria-disabled', 'true');
      whatsappOrder.addEventListener('click', (event) => {
        event.preventDefault();
        whatsappNote.textContent = 'This is still a demo button. Add your authorised business WhatsApp number in script.js to activate it.';
        whatsappNote.classList.add('note-highlight');
      });
    }
  }

  // Menu enquiry links scroll to contact and prefill the WhatsApp message if configured.
  document.querySelectorAll('[data-dish]').forEach((link) => {
    link.addEventListener('click', () => {
      if (whatsappOrder && /^\d{10,15}$/.test(restaurantWhatsAppNumber.replace(/\D/g, ''))) {
        const dish = link.getAttribute('data-dish') || 'the menu';
        whatsappOrder.href = `https://wa.me/${restaurantWhatsAppNumber.replace(/\D/g, '')}?text=${encodeURIComponent(`Hello Bella Kitchen! I would like to ask about ${dish}.`)}`;
      }
    });
  });

  // Reveal sections as they enter view; show content immediately if unsupported.
  const revealItems = document.querySelectorAll('.reveal');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if ('IntersectionObserver' in window && !reduceMotion) {
    const observer = new IntersectionObserver((entries, currentObserver) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          currentObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -35px 0px' });
    revealItems.forEach((item) => observer.observe(item));
  } else {
    revealItems.forEach((item) => item.classList.add('is-visible'));
  }

  // Floating back-to-top shortcut appears after the visitor scrolls.
  const updateTopButton = () => {
    if (floatingTop) floatingTop.classList.toggle('is-visible', window.scrollY > 500);
  };
  updateTopButton();
  window.addEventListener('scroll', updateTopButton, { passive: true });
})();
